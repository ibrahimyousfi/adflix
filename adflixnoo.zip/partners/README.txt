
IMPORTANT:
Place your partner logo images in this folder.

1. This folder (partners) must be inside a folder named 'public' at the root of your project.
2. Name your images: 1.png, 2.png, 3.png, 4.png, 5.png, 6.png
3. If you have different file extensions (like .jpg or .svg), you will need to update the filenames in components/TrustedBy.tsx.
