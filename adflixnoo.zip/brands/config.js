window.APP_CONFIG = {
  // 👇 CHANGE YOUR FACEBOOK PIXEL ID HERE 👇
  PIXEL_ID: "727924226815780",

  // 👇 CHANGE YOUR GOOGLE SCRIPT URL HERE 👇
  GOOGLE_SCRIPT_URL: "https://script.google.com/macros/s/AKfycbyqG0ysPh4Chp2pByFYqwYY6t5dMta4ZIDBkePmCrWDg8Sx3oi-GsyhFs_6D-stWCUi0A/exec"
};